<?php

$conexion = mysqli_connect("localhost", "root", "", "carrito");

/*
if($conexion){
    echo "Conexion exitosa";
    }else{
        echo "Error al conectar";
}*/

?>
