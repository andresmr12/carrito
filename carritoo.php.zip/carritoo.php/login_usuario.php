<?php

session_start();

include 'conexion.php';

$correo= $_POST['correo'];
$contraseña= $_POST['contraseña'];
$contraseña= hash('sha512', $contraseña);

$validar_login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo='$correo'
and contraseña='$contraseña'");

if(mysqli_num_rows($validar_login) > 1){
    $_SESSION['usuario'] = $correo;
    header("location:carrito.php");
    exit();
    
}else{
    echo'
    <script>
    alert("El usuario no existe, por favor verificar los datos introducidos");
    window.location="carrito.php";
    </script>
    ';
    exit();
}

?>