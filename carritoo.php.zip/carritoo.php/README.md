# Carrito de Compras en PHP y MySQL

<img src="https://i0.wp.com/www.configuroweb.com/wp-content/uploads/2022/06/Carrito-de-Compras-en-PHP-y-MySQL.png?resize=800%2C500&ssl=1">

Este de Sistema Carrito de Compras en PHP y MySQL sobre el que comparto el código, permite gestionar las órdenes de compra de los clientes, de manera sencilla y efectiva.

Más información en el siguiente enlace:

<a href="https://www.configuroweb.com/carrito-de-compras-en-php-y-mysql/">Carrito de Compras en PHP y MySQL</a>
