
<?php
include 'Configuracion.php';

if($_POST){

  $nombre=(isset($_POST['nombre'])?$_POST['nombre']:"");
  $descripcion(isset($_POST['descripcion'])?$_POST['descripcion']:"");
  $nombre=(isset($_POST['precio'])?$_POST['precio']:"");

 

}

?>




<!DOCTYPE html>
<html lang="en">

<head>
    <title>AGREGAR PRODUCTO</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <style>
        .container {
            padding: 20px;
        }


      

        
    </style>
</head>

<body>
    <div class="container">
        <div class="panel panel-default">
            <div class="panel-heading">

                <ul class="nav nav-pills">
                    <li role="presentation"><a href="carrito.php">Inicio</a></li>
                    <li role="presentation"><a href="VerCarta.php">Carrito de Compras</a></li>
                    <li role="presentation"><a href="Pagos.php">Pagar</a></li>
                   
            </div>
        </div>


    <div class="form-group col-md-7">
    <label > NOMBRE</label>
    <input type="text" class="form-control" nombre="nombre" aria-describedby="emailHelp" placeholder="Enter email">
  </div>
  
  <div class="form-group col-md-7">
    <label >DESCRIPCION</label>
    <input type="text" class="form-control" nombre="descripcion" placeholder="Descripcion">
  </div>
  <div class="form-group col-md-7">
    <label for=>PRECIO</label>
    <input type="password" class="form-control" nombre="precio" placeholder="Precio">
  </div>
  <div class="form-group col-md-7">
    <label >FECHA DE CREACION</label>
    <input type="date" class="form-control" nombre="fecha" placeholder="Fecha creaciom">
  </div>
  <div class="form-group col-md-8">
  <button class="btn btn-primary" type="submit" class="btn btn-primary">Submit</button>
  </div>
</form>

    </div>

    </div>
    
    




</body>

</html>